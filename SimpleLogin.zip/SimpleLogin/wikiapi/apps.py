from django.apps import AppConfig


class WikiapiConfig(AppConfig):
    name = 'wikiapi'
