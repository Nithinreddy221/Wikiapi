from django.db import models

# Create your models here.

class SearchList(models.Model):
	search_query = models.CharField(max_length=100, null=True, blank=True)
	query_results = models.TextField(null=True, blank=True)
	
	class Meta:
		db_table = "search_list"

class DataResults(models.Model):
	keyword = models.CharField(max_length=100, null=True, blank=True)
	keyword_data = models.TextField(null=True, blank=True)
	file_name = models.TextField(null=True, blank=True)

	class Meta:
		db_table = "data_results"
