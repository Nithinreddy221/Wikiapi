/**
 * Selecter.
 *
 * @author Htmlstream
 * @version 1.0
 * @requires chart.js (v1.0.3)
 *
 */
;(function($){
	'use strict';

	$(document).on('click','.js-selecter',function(){ this.select(); });

})(jQuery);