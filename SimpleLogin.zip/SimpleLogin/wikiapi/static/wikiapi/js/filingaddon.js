    function gtag_report_conversion(url) {
      var callback = function () {
        if (typeof(url) != 'undefined') {
          window.location = url;
        }
      };
      gtag('event', 'conversion', {
          'send_to': 'AW-796315580/3aRqCIrN1oYBELyf2_sC',
          'event_callback': callback
      });
      return false;
    }

    function submitform(){
        var name=document.getElementById('nameid').value;    
        var email=document.getElementById('emailid').value;    
        var phone=document.getElementById('phoneid').value;    
        var company=document.getElementById('companyid').value;   

        xhttp = new XMLHttpRequest();
        xhttp.open('POST', '/formcontact/');
        xhttp.setRequestHeader('Content-Type', 'application/json');
        xhttp.responseType = 'blob';

        xhttp.send(JSON.stringify({'name':name,'email':email,'phone':phone,'company':company})); 

        var formele = document.getElementById('messageholder');
        formele.innerHTML = '<div style="color:white;"><b>Thanks for your interest, we will get back to you shortly.</b></div>';
        document.getElementById('nameid').value='';
        document.getElementById('emailid').value='';
        document.getElementById('phoneid').value='';
        document.getElementById('companyid').value='';
        return false;
    }
    
    function submitform2(){
        var name=document.getElementById('overlayname').value;    
        var email=document.getElementById('overlayemail').value;    
        var phone=document.getElementById('overlayphone').value;    
        var company=document.getElementById('overlaycompany').value;   

        xhttp = new XMLHttpRequest();
        xhttp.open('POST', '/formcontact/');
        xhttp.setRequestHeader('Content-Type', 'application/json');
        xhttp.responseType = 'blob';

        xhttp.send(JSON.stringify({'name':name,'email':email,'phone':phone,'company':company})); 
        console.log({'name':name,'email':email,'phone':phone,'company':company});
        return false;
    }
    




function call_overlay(){
setTimeout(function() {
   $('#myModal').modal();
}, 15000);	
}
call_overlay()


    




window.onload = function(){

    var linktag = document.createElement('link');
    linktag.rel = 'icon';
    linktag.href = "/assets/img/logo/raltin_R.png";
    linktag.type="image/gif";
    linktag.sizes="16x16"
    document.head.appendChild(linktag);


    var linktag2 = document.createElement('link');
    linktag2.rel = 'stylesheet';
    linktag2.href = "/assets/vendor/bootstrap/bootstrap.min.css";
    document.head.appendChild(linktag2);



    var linktag4 = document.createElement('script');
    linktag4.src = "/assets/vendor/bootstrap/popper.min.js";
    linktag4.async=true;
    document.head.appendChild(linktag4);

    var linktag3 = document.createElement('script');
    linktag3.src = "/assets/vendor/bootstrap/bootstrap.min.js";
    document.head.appendChild(linktag3);



    var googlescr = document.createElement('script')
    googlescr.src = 'https://www.googletagmanager.com/gtag/js?id=UA-122687015-1';
    googlescr.async = true;

    var googlescr2 = document.createElement('script')

    var googletagcode="window.dataLayer = window.dataLayer || [];\
        function gtag(){dataLayer.push(arguments);}\
        gtag('js', new Date());\
        gtag('config', 'UA-122687015-1');"
    googlescr2.innerHTML=googletagcode;
    document.head.appendChild(googlescr);
    document.head.appendChild(googlescr2);


    var googleads = document.createElement('script')
    googleads.src = 'https://www.googletagmanager.com/gtag/js?id=AW-796315580';
    googleads.async = true;
    
    var googleads2 = document.createElement('script')
    
    var googleadtagcode="window.dataLayer = window.dataLayer || [];\
        function gtag(){dataLayer.push(arguments);}\
        gtag('js', new Date());\
        gtag('config', 'AW-796315580');"
    googleads2.innerHTML=googleadtagcode;
    document.head.appendChild(googleads);
    document.head.appendChild(googleads2);




    var body = document.getElementsByTagName("body")[0];


    var div = document.createElement("div");
    var topform = "<script type='javascript'>\
        </script><div class='pageheader'>\
            <div style='color:white;font-size:small;padding-left:10px;text-align:center;margin-bottom:0.5%'><b>Get In Touch To Download Unlimited 10-K Tables</b></div>\
            <div style='float:left;width:10%;'> <a href='/'>\
                    <img class='logo' src='/assets/img/logo/raltin_white_logo.png'></a></div>\
        <div style='width:10%;color:white;float:left;font-size:small;padding-left:10px;padding-right:10px;'><a href='/kd/'><p style='color:white;'>Search & Download More Excel 10-K Tables</p></a></div>\
        <form id='upperform' style='display:inline;' class='form-inline' onsubmit='return false;'>\
        <input id='nameid' type='name' class='form-control  input-sm' name='name' placeholder='Name'>\
        <input id='emailid' type='email' class='form-control  input-sm' name='email' placeholder='Email'>\
        <input id='phoneid' type='phone' class='form-control  input-sm' name='phone' placeholder='Phone'>\
        <input id='companyid' class='form-control  input-sm' name='company' placeholder='Company'>\
        <button onclick='submitform()' class='btn btn-default'>Submit</button>\
        </form>\
        <div id='messageholder'></div>\
        </div>";
        




        
        var alldbutton = document.createElement("button");
        alldbutton.innerHTML = "Download all tables in this filing";
        alldbutton.className = "downloadallbutton";
        alldbutton.addEventListener ("click", downloadall ,false);

      



        function downloadall(btn) {
            xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
            var a;
            gtag_report_conversion();
            if (xhttp.readyState === 4 && xhttp.status === 200) {

                var filename = "";
                var filecontent = xhttp.response;
                var disposition = xhttp.getResponseHeader('Content-Disposition');


                var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                var matches = filenameRegex.exec(disposition);
                //console.log(matches);
                filename = matches[1].replace(/['"]/g, '');
                
                a = document.createElement('a');
                a.href = window.URL.createObjectURL(filecontent);

                a.download = filename;
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                }
            };

            var arr=document.location.href.split("/");
            xhttp.open("POST", "/parsealltables/"+arr[4]+"/"+arr[5]+"/");
            console.log("/parsealltables/"+arr[4]+"/"+arr[5]+"/");
            xhttp.setRequestHeader("Content-Type", "application/json");
            xhttp.responseType = 'blob';
            xhttp.send(JSON.stringify({"html":"","url":arr}));

            
        };
        
   

    div.innerHTML=topform;
   
    body.insertAdjacentElement("beforebegin", div);
    div.appendChild(alldbutton);


    var touchDevice = (navigator.maxTouchPoints || 'ontouchstart' in document.documentElement);

    if (touchDevice){
    //if (true){
	var pghdr=document.getElementsByClassName("pageheader")[0];
	pghdr.style.height = "8%";
    }
    
    //get html for dialog
    dialdiv = document.createElement('div');
    dialdiv.setAttribute("id", "dialogholder");
    document.body.appendChild(dialdiv);

    

    var dialoghttp = new XMLHttpRequest();

    dialoghttp.onreadystatechange = function() {
            if (dialoghttp.readyState === 4 && dialoghttp.status === 200) {
                    var dialogtext=dialoghttp.responseText;
                    //console.log(dialogtext);
                    document.getElementById('dialogholder').innerHTML=dialogtext;
                }
            };

	dialoghttp.open( 'GET', /dialogserve/ );
	dialoghttp.responseType = 'text';
	dialoghttp.send();


    //diaglog code ends









    var tables = document.getElementsByName("downloadtable");
    
    for (var j = 0; j < tables.length; j++){
        //var pnode = tables[j].parentNode;
        var tblid = tables[j];
        //var tableid = tables[j].id;
        

        var button = document.createElement("button");
        button.innerHTML = "Download this table";
        button.tblid = tblid;
        button.className = "downloadbutton";
        button.addEventListener ("click", sendhtml ,false);
        
        
        if (tables[j].hasAttribute("name2")){
            var button2 = document.createElement("button");
            button2.innerHTML = "Download this table for all years";
            button2.tblid = tblid;
            button2.className = "downloadbutton";
            button2.addEventListener ("click", sendtableid ,false);    
        
        }


        function sendhtml(btn) {
            var tableele = btn.target.tblid;
            var elehtml = tableele.outerHTML;
            
            xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
            var a;
            
            gtag_report_conversion();
            
            if (xhttp.readyState === 4 && xhttp.status === 200) {

                var filename = "";
                var filecontent = xhttp.response;
                var disposition = xhttp.getResponseHeader('Content-Disposition');


                var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                var matches = filenameRegex.exec(disposition);
                //console.log(matches);
                filename = matches[1].replace(/['"]/g, '');
                
                a = document.createElement('a');
                a.href = window.URL.createObjectURL(filecontent);

                a.download = filename;
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                }
            };

            var cururl = window.location.href;
            xhttp.open("POST", "/parsetable/");
            console.log("posted");
            xhttp.setRequestHeader("Content-Type", "application/json");
            xhttp.responseType = 'blob';
            xhttp.send(JSON.stringify({"html":elehtml,'url':cururl}));

            
        };
        
        function sendtableid(btn) {
            var tablid = btn.target.tblid;
            var tableid = tablid.id;
            var url = window.location.href;
            
            xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
            var a;
            if (xhttp.readyState === 4 && xhttp.status === 200) {

                a = document.createElement('a');
                a.href = window.URL.createObjectURL(xhttp.response);

                a.download = "table.xls";
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                }
            };

            
            xhttp.open("POST", "/combinedtables/");
            console.log("posted");
            xhttp.setRequestHeader("Content-Type", "application/json");
            xhttp.responseType = 'blob';
            console.log({"tablid":tableid,"url":url});
            xhttp.send(JSON.stringify({"tablid":tableid,"url":url}));

            
        }; 
        
        tables[j].insertAdjacentElement("beforebegin", button);
        if (tables[j].hasAttribute("name2")){
            tables[j].insertAdjacentElement("beforebegin", button2);
            }
        
        }
    
}
