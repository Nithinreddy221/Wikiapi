from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
	path('login/', views.view_login, name='login'),
	path('signup/', views.view_signup, name='signup'),
	path('logout/', views.view_logout, name='logout'),
	path('data/<str:search_name>/', views.view_data_result, name="data"),
	path(r'download/<str:fi_name>/', views.dp_view_pdf, name="download"),
]

