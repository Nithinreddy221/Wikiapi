from django.shortcuts import render, render_to_response, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse,Http404
from django.http import HttpResponseRedirect
from django.contrib.auth.models import User, Group
from .models import *
from django.contrib.auth.forms import UserCreationForm
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import wikipedia
import pdfkit
import os, sys
# Create your views here.


outfile = "static/pdf_files/"

@login_required(login_url='/login/')
def index(request):
	if request.method == 'POST':
		print (request.POST, request.POST['search'], "in views")
		search_string = request.POST.get('search')
		if search_string:
			wiki_search = wikipedia.search(search_string, results=11)[1:]
			SearchList.objects.create(search_query=search_string, query_results=wiki_search)
	return render(request, 'home.html', locals())


def dp_view_pdf(request, fi_name):
	file_name = fi_name+".pdf"
	file_obj = DataResults.objects.filter(file_name = file_name)
	file_n = str(file_name)
	file_path = os.path.join(outfile, file_name)
	print(file_path)
	if os.path.exists(file_path):
		with open(file_path, 'rb') as fh:
		    response = HttpResponse(fh.read(), content_type='application/pdf')
		    response['Content-Disposition'] = 'attachment; filename=' + os.path.basename(file_path)
		    return response
	raise Http404


def view_data_result(request, search_name):
	wiki_search = wikipedia.summary(search_name)
	search_name = search_name.replace(" ", "_")+".pdf"
	pdfkit.from_string(wiki_search, "static/pdf_files/"+search_name)
	DataResults.objects.create(keyword=search_name, keyword_data=wiki_search, file_name=search_name)
	search_name = search_name.split(".")[0]
	s_name = search_name.replace("_", " ")
	return render(request, 'data_file.html', locals()) 	

def view_login(request):
    if request.user.is_authenticated:
        user=request.user.id
        return redirect('/')

    if request.method=='POST':
        uname = request.POST.get('username', None)
        passwd = request.POST.get('password', None)
        
        user = authenticate(request, username=uname, password=passwd)
        
        if user and user.is_active:
            login(request, user)
            return redirect('/')
        else:
            error_msg = "Your User ID & Password Combination is Incorrect"
            
    return render(request, 'login.html', locals())


def view_logout(request):
    logout(request)
    return redirect('/login/')

def view_signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('/')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})
